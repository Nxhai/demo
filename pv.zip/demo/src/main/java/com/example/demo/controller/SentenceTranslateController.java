package com.example.demo.controller;

import com.example.demo.dto.SentenceTranslateDTO;
import com.example.demo.service.SentenceTranslateService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
public class SentenceTranslateController {

    private final SentenceTranslateService sentenceTranslateService;

    @GetMapping("/api/sentences-translate")
    public ResponseEntity<SentenceTranslateDTO> getAll(@RequestParam("pageIndex") Integer pageIndex,
                                                       @RequestParam("pageSize") Integer pageSize) {
        SentenceTranslateDTO sentenceTranslate = sentenceTranslateService.getAllSentenceTranslate(pageIndex, pageSize);

        return ResponseEntity.ok(sentenceTranslate);
    }
}
