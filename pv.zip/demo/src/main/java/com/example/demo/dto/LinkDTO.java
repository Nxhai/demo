package com.example.demo.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LinkDTO {
    private Long sentenceId;
    private Long translationId;

    public static LinkDTO of(String[] values) {
        if (values.length == 2) {
            return LinkDTO.builder()
                    .sentenceId(Long.valueOf(values[0]))
                    .translationId(Long.valueOf(values[1]))
                    .build();
        }
        return LinkDTO.builder().build();
    }
}
