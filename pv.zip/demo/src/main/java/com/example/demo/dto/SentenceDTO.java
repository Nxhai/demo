package com.example.demo.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SentenceDTO {
    private Long id;
    private String lang;
    private String text;

    public static SentenceDTO of(String[] values) {
        if (values.length == 3) {
            return SentenceDTO.builder()
                    .id(Long.valueOf(values[0]))
                    .lang(values[1])
                    .text(values[2])
                    .build();
        }
        return SentenceDTO.builder().build();
    }
}
