package com.example.demo.dto;

import com.example.demo.entities.SentenceTranslateEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Page;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SentenceTranslateDTO {

    private List<SentenceTranslateEntity> sentenceTranslates;
    private PageDTO page;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PageDTO {
        private long pageIndex;
        private long pageSize;
        private long totalElement;

        public static PageDTO of(long pageIndex, long pageSize, long totalElement) {
            return PageDTO.builder()
                    .pageIndex(pageIndex)
                    .pageSize(pageSize)
                    .totalElement(totalElement)
                    .build();
        }
    }

    public static SentenceTranslateDTO of(Page<SentenceTranslateEntity> sentencesTranslate) {

        return SentenceTranslateDTO.builder()
                .sentenceTranslates(sentencesTranslate.getContent())
                .page(
                        PageDTO.of(
                                sentencesTranslate.getPageable().getPageNumber(),
                                sentencesTranslate.getPageable().getPageSize(),
                                sentencesTranslate.getTotalElements())
                )
                .build();
    }
}
