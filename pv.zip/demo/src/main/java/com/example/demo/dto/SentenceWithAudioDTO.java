package com.example.demo.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SentenceWithAudioDTO {
    private Long sentenceId;
    private String username;
    private String license;
    private String attributionUrl;

    public static SentenceWithAudioDTO of(String[] values) {
        if (values.length == 4) {
            return SentenceWithAudioDTO.builder()
                    .sentenceId(Long.valueOf(values[0]))
                    .username(values[1])
                    .license(values[2])
                    .attributionUrl(values[3])
                    .build();
        }
        return SentenceWithAudioDTO.builder().build();
    }
}
