package com.example.demo.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "sentences_translate")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SentenceTranslateEntity extends AuditableEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sentence_id")
    private Long sentenceId;

    @Column(name = "text", length = 5000)
    private String text;

    @Column(name = "attribution_url")
    private String attributionUrl;

    @Column(name = "translation_id")
    private Long translationId;

    @Column(name = "translation_text", length = 5000)
    private String translationText;

}
