package com.example.demo.service;

import com.example.demo.dto.LinkDTO;
import com.example.demo.dto.SentenceDTO;
import com.example.demo.dto.SentenceWithAudioDTO;
import com.example.demo.entities.SentenceTranslateEntity;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;

public interface PrepareDataService {
    void readDataSentenceFromCsv(Map<String, SentenceDTO> mapEngSentences,
                                 Map<String, SentenceDTO> mapVieSentences);

    List<LinkDTO> readDataLinkFromCsv() throws FileNotFoundException;

    void readDataAudioFromCsv(Map<String, SentenceWithAudioDTO> mapAudios);

    List<SentenceTranslateEntity> prepareDataTranslates(Map<String, SentenceDTO> mapEngSentences,
                                                        Map<String, SentenceDTO> mapVieSentences,
                                                        List<LinkDTO> links,
                                                        Map<String, SentenceWithAudioDTO> mapAudios);

    void writeFileCsv(List<SentenceTranslateEntity> translateEntities);
}
