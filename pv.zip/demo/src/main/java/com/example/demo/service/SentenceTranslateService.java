package com.example.demo.service;

import com.example.demo.dto.SentenceTranslateDTO;

public interface SentenceTranslateService {
    SentenceTranslateDTO getAllSentenceTranslate(Integer pageIndex, Integer pageSize);

}
