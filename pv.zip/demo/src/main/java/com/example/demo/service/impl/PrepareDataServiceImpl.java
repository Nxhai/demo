package com.example.demo.service.impl;

import com.example.demo.dto.LinkDTO;
import com.example.demo.dto.SentenceDTO;
import com.example.demo.dto.SentenceWithAudioDTO;
import com.example.demo.entities.SentenceTranslateEntity;
import com.example.demo.repository.SentenceTranslateEntityRepository;
import com.example.demo.service.PrepareDataService;
import com.example.demo.utils.Constant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import javax.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.apache.logging.log4j.util.Strings.EMPTY;

@Slf4j
@Service
public class PrepareDataServiceImpl implements PrepareDataService {

    private final SentenceTranslateEntityRepository sentenceTranslateEntityRepository;

    private final String fileSentenceTranslate;

    public PrepareDataServiceImpl(SentenceTranslateEntityRepository sentenceTranslateEntityRepository,
                                  @Value("${output.file.csv.sentence-translate}") String fileSentenceTranslate) {
        this.sentenceTranslateEntityRepository = sentenceTranslateEntityRepository;
        this.fileSentenceTranslate = fileSentenceTranslate;
    }

    @PostConstruct
    @Transactional
    public void writeFileTranslateCsv() throws FileNotFoundException {

        Map<String, SentenceDTO> mapEngSentences = new HashMap<>();
        Map<String, SentenceDTO> mapVieSentences = new HashMap<>();
        Map<String, SentenceWithAudioDTO> mapAudios = new HashMap<>();

        // read 3 csv file
        CompletableFuture<List<LinkDTO>> links = readCsvFiles(mapEngSentences, mapVieSentences, mapAudios);

        // prepare data
        List<SentenceTranslateEntity> translateEntities = new ArrayList<>();
        try {
            translateEntities = this.prepareDataTranslates(mapEngSentences, mapVieSentences, links.get(), mapAudios);
        } catch (InterruptedException | ExecutionException e) {
            log.error("*********** Error when WriteFileTranslateCsv {}", e.getMessage());
        }

        // write to file translate_eng_vie.csv
        this.writeFileCsv(translateEntities);

        // save to db
        log.info("************* Save to db...... *************");
        sentenceTranslateEntityRepository.deleteAll();
        sentenceTranslateEntityRepository.saveAll(translateEntities);
        log.info("************* Save to db success *************");

        log.info("************* Create file translate & save to database success *************");
    }

    private CompletableFuture<List<LinkDTO>> readCsvFiles(Map<String, SentenceDTO> mapEngSentences,
                                                          Map<String, SentenceDTO> mapVieSentences,
                                                          Map<String, SentenceWithAudioDTO> mapAudios) {

        log.info("************* Start reading files csv *************");
        CompletableFuture<Void> sentences =
                CompletableFuture.runAsync(() -> this.readDataSentenceFromCsv(mapEngSentences, mapVieSentences));

        CompletableFuture<Void> audios =
                CompletableFuture.runAsync(() -> this.readDataAudioFromCsv(mapAudios));

        CompletableFuture<List<LinkDTO>> links = CompletableFuture.supplyAsync(this::readDataLinkFromCsv);


        CompletableFuture.allOf(sentences, links, audios);
        log.info("************* Reading files csv success *************");

        return links;
    }


    @Override
    public void readDataSentenceFromCsv(Map<String, SentenceDTO> mapEngSentences,
                                        Map<String, SentenceDTO> mapVieSentences) {

        File file;
        try {
            file = ResourceUtils.getFile(Constant.PATH_SENTENCE_CSV);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            SentenceDTO sentenceDTO;

            while ((line = br.readLine()) != null) {
                String[] values = line.split(Constant.TAB);
                sentenceDTO = SentenceDTO.of(values);

                if (Objects.nonNull(sentenceDTO.getId()) && Objects.equals(sentenceDTO.getLang(), Constant.ENG)) {
                    mapEngSentences.put(sentenceDTO.getId().toString(), sentenceDTO);
                }

                if (Objects.nonNull(sentenceDTO.getId()) && Objects.equals(sentenceDTO.getLang(), Constant.VIE)) {
                    mapVieSentences.put(sentenceDTO.getId().toString(), sentenceDTO);
                }
                log.info("*********** Loading sentence id {} **************", sentenceDTO.getId());
            }

        } catch (Exception e) {
            log.error("************** Error when read file sentences.csv {}", e.getMessage());
        }
    }

    @Override
    public List<LinkDTO> readDataLinkFromCsv() {

        List<LinkDTO> links = new ArrayList<>();
        File file;
        try {
            file = ResourceUtils.getFile(Constant.PATH_LINK_CSV);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            LinkDTO linkDTO;

            while ((line = br.readLine()) != null) {
                String[] values = line.split(Constant.TAB);
                linkDTO = LinkDTO.of(values);
                links.add(linkDTO);
                log.info("*********** Loading link {} - {} **************", linkDTO.getSentenceId(), linkDTO.getTranslationId());
            }
        } catch (IOException e) {
            log.error("*****Error when read file links.csv {}", e.getMessage());
        }
        return links;
    }

    @Override
    public void readDataAudioFromCsv(Map<String, SentenceWithAudioDTO> mapAudios) {

        File file;
        try {
            file = ResourceUtils.getFile(Constant.PATH_SENTENCE_WITH_AUDIO_CSV);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            String line;
            SentenceWithAudioDTO sentenceWithAudio;

            while ((line = br.readLine()) != null) {
                String[] values = line.split(Constant.TAB);
                sentenceWithAudio = SentenceWithAudioDTO.of(values);

                if (Objects.nonNull(sentenceWithAudio.getSentenceId())) {
                    mapAudios.put(sentenceWithAudio.getSentenceId().toString(), sentenceWithAudio);
                }

                log.info("*********** Loading sentence_with_audio {} **************", sentenceWithAudio.getSentenceId());
            }
        } catch (IOException e) {
            log.error("*****Error when read file sentence_with_audio.csv {}", e.getMessage());
        }

    }

    @Override
    public List<SentenceTranslateEntity> prepareDataTranslates(Map<String, SentenceDTO> mapEngSentences,
                                                               Map<String, SentenceDTO> mapVieSentences,
                                                               List<LinkDTO> links,
                                                               Map<String, SentenceWithAudioDTO> mapAudios) {

        log.info("************* Start prepare translates *************");
        List<SentenceTranslateEntity> translateEntities = new ArrayList<>();
        SentenceTranslateEntity sentenceTranslateEntity;

        SentenceDTO sentenceEng;
        SentenceDTO sentenceVie;

        for (LinkDTO link : links) {

            sentenceEng = mapEngSentences.get(link.getSentenceId().toString());
            sentenceVie = mapVieSentences.get(link.getTranslationId().toString());

            if (Objects.nonNull(sentenceEng) && Objects.nonNull(sentenceVie)) {
                sentenceTranslateEntity = SentenceTranslateEntity.builder()
                        .sentenceId(sentenceEng.getId())
                        .text(sentenceEng.getText())
                        .attributionUrl(getAttributionUrl(mapAudios, sentenceEng))
                        .translationId(sentenceVie.getId())
                        .translationText(sentenceVie.getText())
                        .build();

                log.info(".............. Prepare SentenceTranslateEntity [{} - {} - {} - {} - {}] .............",
                        sentenceTranslateEntity.getSentenceId(),
                        sentenceTranslateEntity.getText(),
                        sentenceTranslateEntity.getAttributionUrl(),
                        sentenceTranslateEntity.getTranslationId(),
                        sentenceTranslateEntity.getTranslationText());

                translateEntities.add(sentenceTranslateEntity);
            }
        }

        log.info("************* Prepare List SentenceTranslateEntity success *************");
        return translateEntities;
    }

    @Override
    public void writeFileCsv(List<SentenceTranslateEntity> translateEntities) {

        log.info("************* Start write data to file translate_eng_vie.csv success **************");

        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter(this.fileSentenceTranslate);

            // Write the CSV file header
            fileWriter.append("id\tsentence_eng_id\ttext\turl\tsentence_vie_id\ttranslate_text");

            // Add a new line separator after the header
            fileWriter.append(Constant.NEW_LINE);

            for (SentenceTranslateEntity translate : translateEntities) {
                fileWriter.append(String.valueOf(translate.getSentenceId()));

                fileWriter.append(Constant.TAB);
                fileWriter.append(translate.getText());

                fileWriter.append(Constant.TAB);
                fileWriter.append(translate.getAttributionUrl());

                fileWriter.append(Constant.TAB);
                fileWriter.append(String.valueOf(translate.getTranslationId()));

                fileWriter.append(Constant.TAB);
                fileWriter.append(translate.getTranslationText());

                fileWriter.append(Constant.NEW_LINE);
            }

            log.info("************* Write data to translate_eng_vie.csv success **************");

        } catch (Exception e) {
            log.error("************** Error when write to file translate_eng_vie.csv: {}", e.getMessage());
        } finally {
            try {
                fileWriter.flush();
                fileWriter.close();
            } catch (IOException e) {
                log.error("************** Error while flushing/closing fileWriter: {}", e.getMessage());
            }
        }
    }

    private static String getAttributionUrl(Map<String, SentenceWithAudioDTO> mapAudios, SentenceDTO sentenceEng) {
        SentenceWithAudioDTO audio = mapAudios.get(sentenceEng.getId().toString());
        if (Objects.isNull(audio)) {
            return EMPTY;
        }
        return audio.getAttributionUrl().concat("/").concat(sentenceEng.getId().toString()).concat(Constant.MP3);
    }
}
