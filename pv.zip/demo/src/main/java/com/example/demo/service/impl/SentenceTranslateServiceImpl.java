package com.example.demo.service.impl;

import com.example.demo.dto.SentenceTranslateDTO;
import com.example.demo.entities.SentenceTranslateEntity;
import com.example.demo.repository.SentenceTranslateEntityRepository;
import com.example.demo.service.SentenceTranslateService;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
@AllArgsConstructor
public class SentenceTranslateServiceImpl implements SentenceTranslateService {

    private final SentenceTranslateEntityRepository sentenceTranslateEntityRepository;

    @Override
    public SentenceTranslateDTO getAllSentenceTranslate(Integer pageIndex, Integer pageSize) {
        if (Objects.isNull(pageIndex)) {
            pageIndex = 0;
        }
        if (Objects.isNull(pageSize)) {
            pageSize = 10;
        }

        Pageable pageable = PageRequest.of(pageIndex, pageSize);
        Page<SentenceTranslateEntity> sentencesTranslate = sentenceTranslateEntityRepository.findAll(pageable);

        return SentenceTranslateDTO.of(sentencesTranslate);
    }
}
