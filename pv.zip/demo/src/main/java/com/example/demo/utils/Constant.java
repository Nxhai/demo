package com.example.demo.utils;

public class Constant {
    public static final String PATH_SENTENCE_CSV = "classpath:sentences.csv";
    public static final String PATH_LINK_CSV = "classpath:links.csv";
    public static final String PATH_SENTENCE_WITH_AUDIO_CSV = "classpath:sentences_with_audio.csv";
    public static final String ENG = "eng";
    public static final String VIE = "vie";
    public static final String MP3 = ".mp3";
    public static final String TAB = "\t";
    public static final String NEW_LINE = "\n";
}
