CREATE TABLE `demo`.`sentences_translate` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `sentence_id` DOUBLE NULL,
  `text` VARCHAR(5000) NULL,
  `attribution_url` VARCHAR(100) NULL,
  `translation_id` DOUBLE NULL,
  `translation_text` VARCHAR(5000) NULL,
  PRIMARY KEY (`id`));
